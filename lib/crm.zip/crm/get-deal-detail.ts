// lib/crm/get-deal-detail.ts
import { notFound } from "next/navigation";
import { createClient } from "@/lib/supabase/server";

type DealDetailResult = {
  deal: {
    id: string;
    name: string;
    type: string;
    typeLabel: string;
    status: string;
    statusLabel: string;
    stage: string;
    stageLabel: string;
    sector: string;
    priority: string;
    priorityLabel: string;
    valuation: string;
    fundraising: string;
    startDate: string;
    targetDate: string;
    description: string;
    organizationId: string | null;
  };
  organization: {
    id: string;
    name: string;
    country: string;
    website: string;
  } | null;
  contacts: Array<{
    id: string;
    name: string;
    title: string;
    role: string;
    email: string;
    phone: string;
    contacted: string;
    lastContact: string;
    nextFollowUp: string;
  }>;
  documents: Array<{
    id: string;
    name: string;
    type: string;
    version: string;
    status: string;
    date: string;
  }>;
  priorities: Array<{
    id: string;
    title: string;
    description: string;
    priority: string;
    status: string;
    dueDate: string;
  }>;
  checklist: Array<{
    id: string;
    label: string;
    done: boolean;
    status: string;
    dueDate: string;
    note: string;
  }>;
  agenda: Array<{
    id: string;
    title: string;
    description: string;
    startsAt: string;
  }>;
};

function formatDate(value: string | null | undefined) {
  if (!value) return "—";

  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return "—";

  return new Intl.DateTimeFormat("fr-FR", {
    day: "2-digit",
    month: "2-digit",
    year: "numeric",
  }).format(date);
}

function formatDateTime(value: string | null | undefined) {
  if (!value) return "—";

  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return "—";

  return new Intl.DateTimeFormat("fr-FR", {
    day: "2-digit",
    month: "2-digit",
    year: "numeric",
    hour: "2-digit",
    minute: "2-digit",
  }).format(date);
}

function formatMoney(value: number | string | null | undefined, currency = "EUR") {
  if (value === null || value === undefined || value === "") return "—";

  const amount = typeof value === "string" ? Number(value) : value;
  if (Number.isNaN(amount)) return "—";

  return new Intl.NumberFormat("fr-FR", {
    style: "currency",
    currency,
    maximumFractionDigits: 0,
  }).format(amount);
}

function labelDealType(value: string | null | undefined) {
  switch (value) {
    case "mna":
      return "M&A";
    case "venture":
      return "Venture";
    case "advisory":
      return "Advisory";
    default:
      return value ?? "—";
  }
}

function labelDealStatus(value: string | null | undefined) {
  switch (value) {
    case "active":
      return "Actif";
    case "inactive":
      return "Inactif";
    case "closed":
      return "Finalisé";
    default:
      return value ?? "—";
  }
}

function labelDealStage(value: string | null | undefined) {
  switch (value) {
    case "origination":
      return "Origination";
    case "qualification":
      return "Qualification";
    case "analysis":
      return "Analyse";
    case "ioi":
      return "IOI";
    case "loi":
      return "LOI";
    case "due_diligence":
      return "Due diligence";
    case "closing":
      return "Closing";
    default:
      return value ?? "—";
  }
}

function labelPriority(value: string | null | undefined) {
  switch (value) {
    case "high":
      return "Haute";
    case "medium":
      return "Moyenne";
    case "low":
      return "Basse";
    default:
      return value ?? "—";
  }
}

function labelTaskStatus(value: string | null | undefined) {
  switch (value) {
    case "todo":
      return "À faire";
    case "requested":
      return "Demandé";
    case "done":
      return "Finalisé";
    default:
      return value ?? "—";
  }
}

export async function getDealDetail(id: string): Promise<DealDetailResult> {
  const supabase = await createClient();

  const { data: deal, error: dealError } = await supabase
    .from("deals")
    .select("*")
    .eq("id", id)
    .single();

  if (dealError || !deal) {
    notFound();
  }

  const organizationPromise = deal.organization_id
    ? supabase
        .from("organizations")
        .select("id, name, country, website")
        .eq("id", deal.organization_id)
        .maybeSingle()
    : Promise.resolve({ data: null, error: null });

  const contactsPromise = supabase
    .from("deal_contacts")
    .select(`
      id,
      role,
      contacted,
      last_contact_at,
      next_follow_up_at,
      contact:contacts (
        id,
        first_name,
        last_name,
        title,
        email,
        phone
      )
    `)
    .eq("deal_id", id)
    .order("created_at", { ascending: false });

  const documentsPromise = supabase
    .from("documents")
    .select("id, name, type, version, status, document_date")
    .eq("deal_id", id)
    .order("created_at", { ascending: false });

  const prioritiesPromise = supabase
    .from("priorities")
    .select("id, title, description, priority, status, due_date")
    .eq("deal_id", id)
    .order("created_at", { ascending: false });

  const checklistPromise = supabase
    .from("checklist_items")
    .select("id, label, done, status, due_date, note")
    .eq("deal_id", id)
    .order("created_at", { ascending: false });

  const agendaPromise = supabase
    .from("agenda_events")
    .select("id, title, description, starts_at")
    .eq("deal_id", id)
    .order("starts_at", { ascending: true });

  const [
    organizationResult,
    contactsResult,
    documentsResult,
    prioritiesResult,
    checklistResult,
    agendaResult,
  ] = await Promise.all([
    organizationPromise,
    contactsPromise,
    documentsPromise,
    prioritiesPromise,
    checklistPromise,
    agendaPromise,
  ]);

  if (contactsResult.error) throw contactsResult.error;
  if (documentsResult.error) throw documentsResult.error;
  if (prioritiesResult.error) throw prioritiesResult.error;
  if (checklistResult.error) throw checklistResult.error;
  if (agendaResult.error) throw agendaResult.error;
  if (organizationResult.error) throw organizationResult.error;

  const contacts =
    contactsResult.data?.map((row: any) => {
      const contact = Array.isArray(row.contact) ? row.contact[0] : row.contact;

      return {
        id: contact?.id ?? row.id,
        name:
          [contact?.first_name, contact?.last_name].filter(Boolean).join(" ") || "Sans nom",
        title: contact?.title ?? "—",
        role: row.role ?? "—",
        email: contact?.email ?? "—",
        phone: contact?.phone ?? "—",
        contacted: row.contacted ? "Contacté" : "Non contacté",
        lastContact: formatDate(row.last_contact_at),
        nextFollowUp: formatDate(row.next_follow_up_at),
      };
    }) ?? [];

  const documents =
    documentsResult.data?.map((row) => ({
      id: row.id,
      name: row.name ?? "Sans nom",
      type: row.type ?? "—",
      version: row.version ?? "—",
      status: labelTaskStatus(row.status),
      date: formatDate(row.document_date),
    })) ?? [];

  const priorities =
    prioritiesResult.data?.map((row) => ({
      id: row.id,
      title: row.title ?? "Sans titre",
      description: row.description ?? "—",
      priority: labelPriority(row.priority),
      status: labelTaskStatus(row.status),
      dueDate: formatDate(row.due_date),
    })) ?? [];

  const checklist =
    checklistResult.data?.map((row) => ({
      id: row.id,
      label: row.label ?? "Sans libellé",
      done: Boolean(row.done),
      status: labelTaskStatus(row.status),
      dueDate: formatDate(row.due_date),
      note: row.note ?? "—",
    })) ?? [];

  const agenda =
    agendaResult.data?.map((row) => ({
      id: row.id,
      title: row.title ?? "Sans titre",
      description: row.description ?? "—",
      startsAt: formatDateTime(row.starts_at),
    })) ?? [];

  return {
    deal: {
      id: deal.id,
      name: deal.name ?? "Sans nom",
      type: deal.type ?? "—",
      typeLabel: labelDealType(deal.type),
      status: deal.status ?? "—",
      statusLabel: labelDealStatus(deal.status),
      stage: deal.stage ?? "—",
      stageLabel: labelDealStage(deal.stage),
      sector: deal.sector ?? "—",
      priority: deal.priority ?? "—",
      priorityLabel: labelPriority(deal.priority),
      valuation: formatMoney(deal.valuation_amount),
      fundraising: formatMoney(deal.fundraising_amount),
      startDate: formatDate(deal.start_date),
      targetDate: formatDate(deal.target_date),
      description: deal.description ?? "—",
      organizationId: deal.organization_id ?? null,
    },
    organization: organizationResult.data
      ? {
          id: organizationResult.data.id,
          name: organizationResult.data.name ?? "—",
          country: organizationResult.data.country ?? "—",
          website: organizationResult.data.website ?? "—",
        }
      : null,
    contacts,
    documents,
    priorities,
    checklist,
    agenda,
  };
}